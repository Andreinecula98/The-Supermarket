#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

typedef struct Nod1
{
	char* nume;
    char* categorie;
    int pret;
    int cantitate;
    int stoc;
    struct Nod1 *urm;
}lista1;

typedef struct Nod2
{
	char* nume;
    char* categorie;
    int cantitate;
    struct Nod2 *urm;
}lista2;

typedef struct arb
{
    int cant; 
    struct arb *stanga,*dreapta; 
}arbore;

typedef struct Elem
{
    int val; 
    struct Elem* next;
}stiva; 

void stergere_string(char element[], int size){
	int i;
	for (i=0; i<size; i++)
		element[i] = '\0';
}

void sterge_arbore(arbore *radacina)
{
    if (radacina == NULL) return;
 
    sterge_arbore(radacina->stanga);
    sterge_arbore(radacina->dreapta);
    free(radacina);
}

lista1* alocare_nod_tip1()
{
	lista1 *p;
	p = (lista1*)malloc(sizeof(lista1));
	if (!p){
		printf("EROARE alocare p");
		exit(1);
	}
	return p;

}

lista2* alocare_nod_tip2()
{
	lista2 *p;
	p = (lista2*)malloc(sizeof(lista2));
	if (!p){
		printf("EROARE alocare p");
		exit(1);
	}
	return p;

}

int creare_lista1(char fisier[], lista1 **head1)
{
	FILE *f;
	lista1 *q,*p;
	char *a, *b, *sir, sep[] = " \n";
	int nr_produse, i, pas;
	
	
	p = alocare_nod_tip1();
	a = (char*)malloc(sizeof(char)*100);
	b = (char*)malloc(sizeof(char)*100);
	sir = (char*)malloc(sizeof(char)*100);

	
	
	f = fopen(fisier,"r");
	if (!f){
		printf("Eroare deschidere fisier!");
		exit(1);
	}
	
    b = fgets(a,100,f);
   	nr_produse = atoi(b);
   	
    for (i=0; i<nr_produse; i++){
   	 pas = 1;
   	 b = fgets(a,100,f);
	 if (i==0){
		p->nume = (char*)malloc(sizeof(char)*100);
		p->categorie = (char*)malloc(sizeof(char)*100);
	    sir = strtok(b,sep);

	    while (sir != NULL){
		 if (pas == 1)
			strcpy(p->nume,sir);
		 if (pas == 2)
            strcpy(p->categorie,sir);
         if (pas == 3)
        	p->pret = atoi(sir);
         if (pas == 4)
        	p->cantitate = atoi(sir);
         if (pas == 5)
        	p->stoc = atoi(sir);
		
		sir = strtok(NULL,sep);
		pas++;
	  }
	p->urm = NULL;
	*head1 = p;
    }

    else{

    	q = alocare_nod_tip1();
	    q->nume = (char*)malloc(sizeof(char)*100);
		q->categorie = (char*)malloc(sizeof(char)*100);
    	sir = strtok(b, sep);

	    while (sir!=NULL){
		 if (pas == 1)
			strcpy(q->nume,sir);
		 if (pas == 2)
            strcpy(q->categorie,sir);
         if (pas == 3)
        	q->pret = atoi(sir);
         if (pas == 4)
        	q->cantitate=atoi(sir);
         if (pas == 5)
        	q->stoc=atoi(sir);
		
		 sir = strtok(NULL,sep);
		 pas++;
	    }
	
	 q->urm = NULL;
	 p->urm = q;
	 p = q;
    }
   }
   stergere_string(a, 30);
   stergere_string(b, 30);
   stergere_string(sir, 0);
   fclose(f);
   return nr_produse;   
}

 void deschide_cerinte(char cerinte[], int c[])
{
	FILE *f;
	int i;
	char *a, *b, *sir, sep[] = " \n";
	a = (char*)malloc(sizeof(char)*30);
	b = (char*)malloc(sizeof(char)*30);
	sir = (char*)malloc(sizeof(char)*30);

	f = fopen(cerinte, "r");
	if (!f){
		printf("EROARE la deschiderea fisierului");
		exit(1);
	  }

	i = 0;
	b = fgets(a, 30, f);
	sir = strtok(b, sep);

	while (sir != NULL){   		
		c[i] = atoi(sir);
		sir = strtok(NULL, sep);
		i++;
	   }

	b = fgets(a, 30, f);
	c[i] = atoi(b);
	stergere_string(a, 30);
	stergere_string(b, 30);
	stergere_string(sir, 0);
	fclose(f);

}

void creare_lista2(char fisier[], lista2 **head2)
{
	FILE *f;
	lista2 *q, *p;
	char *a, *b, *sir, sep[] = " \n";
    int nr_produse, i, pas;
	
	p = alocare_nod_tip2();	
	a = (char*)malloc(sizeof(char)*100);
	b = (char*)malloc(sizeof(char)*100);
	sir = (char*)malloc(sizeof(char)*100);
	
	f = fopen(fisier,"r");
	if (!f){
		printf("EROARE!");
		exit(1);
	}
	
    b = fgets(a, 100, f);
   	nr_produse = atoi(b);
   
   	
    for (i=0; i<nr_produse; i++){
   	    pas = 1;
   	    b = fgets(a, 100, f);

	    if (i == 0){
		   p->nume = (char*)malloc(sizeof(char)*100);
		   p->categorie = (char*)malloc(sizeof(char)*100);
	       sir = strtok(b,sep);

	       while (sir != NULL){
		     if (pas == 1)
			    strcpy(p->nume, sir);
		     if (pas == 2)
                strcpy(p->categorie, sir);
             if (pas == 3)
        	    p->cantitate = atoi(sir);	
		     sir = strtok(NULL, sep);
		     pas++;
	       }
	      p->urm = NULL;
	      *head2 = p;
         }

        else{

    	q = alocare_nod_tip2();
	    q->nume = (char*)malloc(sizeof(char)*100);
		q->categorie = (char*)malloc(sizeof(char)*100);
    	sir = strtok(b, sep);

	    while(sir != NULL){
		  if (pas == 1)
			strcpy(q->nume, sir);
		  if (pas == 2)
            strcpy(q->categorie, sir);
          if (pas == 3)
        	q->cantitate = atoi(sir);
		
		  sir = strtok(NULL, sep);
		  pas++;
	    }
	
	    q->urm = NULL;
	    p->urm = q;
	    p = q;
      }
   }
   fclose(f);
}

void cerinta_2(lista1 *head1, lista2 **head2, lista1 *q, lista2 *p, int nr_produse_market)
{
	lista2 *aux, *temp;
	char **produs;
	int i, prod_lipsa = 0;

	aux = alocare_nod_tip2();
	temp = alocare_nod_tip2();
	produs = (char**)malloc(sizeof(char*)*nr_produse_market);
	for (i=0; i<nr_produse_market; i++){
		produs[i] = (char*)malloc(sizeof(char)*50);
		if (!produs[i]){
			printf("EROARE");
			exit(1);
		  }
	    }

    for (q=head1; q!=NULL; q=q->urm){
   	  if (q->stoc == 0){
   		strcpy(produs[prod_lipsa], q->nume);
   		prod_lipsa++; 		
   	   }
     }

    for (i=0; i<prod_lipsa; i++){ 		
        if (strcmp((*head2)->nume,produs[i]) == 0){
		   p = (*head2)->urm;
		   temp=(*head2);
		   (*head2) = p;
		   free(temp);		
	    }
	    p = (*head2);
	    aux = (*head2)->urm;

       while (aux != NULL && p != NULL){
   	      if (strcmp(aux->nume ,produs[i]) == 0){
   		    temp = aux;
   		    p->urm = aux->urm;
     	    free(temp);
     	    break;  		
   	       }
   	      p = aux;
   	      aux = aux->urm;
        }
    }
    for (i=0; i<nr_produse_market; i++)
      stergere_string(produs[i], 50);	
}
     	
void cerinta_3(int buget, lista1 *head1, lista2 *head2, lista2 **head3, lista1 *q, lista2 *p, lista2 *z)
{
	lista2 *aux;
	int cant3, pas = 0;

	for (p=head2; p!=NULL; p=p->urm)	
	  for (q=head1; q!=NULL; q=q->urm)
	    if (strcmp(p->nume, q->nume) == 0)
		   if (q->stoc != 0){
				if (buget < q->pret)
					break;
				cant3 = 0;
				if (q->cantitate <= p->cantitate){
					while (buget >= q->pret && cant3 < q->cantitate){
						cant3++;
						buget = buget - q->pret;
					}
				}

				else{
				    while (buget >= q->pret && cant3 < p->cantitate){
						cant3++;
						buget = buget - q->pret;
					}
				}

				if (pas == 0){
					z->nume = (char*)malloc(sizeof(char)*100);
		            z->categorie = (char*)malloc(sizeof(char)*100);
		            strcpy(z->nume, p->nume);
		            strcpy(z->categorie, p->categorie);		               
		            z->cantitate = cant3;
		            z->urm = NULL;
		            (*head3) = z;    
				}

				else{
                    aux = alocare_nod_tip2();
	                aux->nume = (char*)malloc(sizeof(char)*100);
		            aux->categorie = (char*)malloc(sizeof(char)*100);
                    strcpy(aux->nume, p->nume);
		            strcpy(aux->categorie, p->categorie);
		            aux->cantitate = cant3;
		            aux->urm = NULL;
		            z->urm = aux;
		            z = aux;		                    
					}
				pas++;
			}

}


void cerinta_4(lista1 *head1, lista2 *head2, lista2 **head3, lista1 *q, lista2 *p, lista2 *z)
{
	lista2 *aux;
	lista1 *help;
	char *nume1, *categorie1;
	int pas = 0, dif, difmin, cantitate;
	nume1 = (char*)malloc(sizeof(char)*100);
	categorie1 = (char*)malloc(sizeof(char)*100);
	help = alocare_nod_tip1();

	for (p=head2; p!=NULL; p=p->urm)
	    for (q=head1; q!=NULL; q=q->urm)
			if (strcmp(p->nume, q->nume) == 0){
				difmin = 100;
					if (p->cantitate <= q->cantitate){
					  if (pas == 0){
						z->nume = (char*)malloc(sizeof(char)*100);
		                z->categorie = (char*)malloc(sizeof(char)*100);
		                strcpy(z->nume, p->nume);
		                strcpy(z->categorie, p->categorie);
		                z->cantitate = p->cantitate;
		                z->urm = NULL;
		                (*head3) = z;
					   }
					  else{
                           aux = alocare_nod_tip2();
	                       aux->nume = (char*)malloc(sizeof(char)*100);
		                   aux->categorie = (char*)malloc(sizeof(char)*100);
                           strcpy(aux->nume, p->nume);
		                   strcpy(aux->categorie, p->categorie);
		                   aux->cantitate = p->cantitate;
		                   aux->urm = NULL;
		                   z->urm = aux;
		                   z = aux;

					   }
					p->cantitate = 0;
					pas++;
					}

					else{
						for (help=head1; help!=NULL; help=help->urm){
						  if (strcmp(help->categorie, q->categorie) == 0 && strcmp(help->nume, q->nume) != 0){
							dif = abs(q->pret - help->pret);
								if (difmin > dif){
								  strcpy(nume1, help->nume);
								  strcpy(categorie1, help->categorie);
								  cantitate = help->cantitate;
								  difmin = dif;
								}
						  }
						}	
						if (pas == 0){
						z->nume = (char*)malloc(sizeof(char)*100);
		                z->categorie = (char*)malloc(sizeof(char)*100);
		                z->urm = alocare_nod_tip2();
		                z->urm->nume = (char*)malloc(sizeof(char)*100);
		                z->urm->categorie = (char*)malloc(sizeof(char)*100);
		                strcpy(z->nume, p->nume);     
		                strcpy(z->categorie, p->categorie);
		                strcpy(z->urm->nume, nume1);
		                strcpy(z->urm->categorie, categorie1);
		                z->cantitate = q->cantitate;

		                if ((p->cantitate) - (q->cantitate) < cantitate)
		                	z->urm->cantitate = (p->cantitate) - (q->cantitate);
		                else
		                	z->urm->cantitate = cantitate;
		                z->urm->urm = NULL;
		                (*head3) = z;
		                z = z->urm;
					}

					    else{
                            aux = alocare_nod_tip2();
	                        aux->nume = (char*)malloc(sizeof(char)*100);
		                    aux->categorie = (char*)malloc(sizeof(char)*100);
		                    aux->urm = alocare_nod_tip2();
		                    aux->urm->nume = (char*)malloc(sizeof(char)*100);
		                    aux->urm->categorie = (char*)malloc(sizeof(char)*100);
                            strcpy(aux->nume, p->nume);
		                    strcpy(aux->categorie, p->categorie);
		                    strcpy(aux->urm->nume, nume1);
		                    strcpy(aux->urm->categorie, categorie1);
		                    aux->cantitate = q->cantitate;
		                    if((p->cantitate) - (q->cantitate) < cantitate)
		                	   aux->urm->cantitate = p->cantitate - q->cantitate;
		                    else
		                	   aux->urm->cantitate = cantitate;
		                    aux->urm->urm = NULL;
		                    z->urm = aux;
		                    z = aux->urm;
					    }
                      pas++;
					}
				p->cantitate = 0;	
			}
			stergere_string(nume1, 100);
			stergere_string(categorie1, 100);
			free(help);
}

arbore* creare_arbore(int N, int v[], int *i){ 
    int val;
      if (N > 0){
        arbore* radacina= (arbore*)malloc(sizeof(arbore));
        (radacina->cant) = v[*i];
        (*i)++;
        radacina->stanga = creare_arbore(N/2, v, &(*i));
        radacina->dreapta = creare_arbore(N-1-N/2, v, &(*i));
        return radacina;
      }
      else return NULL;
}

int cerinta_5(lista2 *head3, lista2 *p, int v[], arbore **radacina){
	int i,j,aux,nr_prod = 0;
	v = (int*)malloc(sizeof(int)*30);
	
	for (p=head3; p!=NULL; p=p->urm){
		v[nr_prod] = p->cantitate;
		nr_prod++;
		}

	for (i=0; i<nr_prod-1; i++)
		for (j=i+1; j<nr_prod; j++){
			if (v[i] > v[j]){
				aux = v[i];
				v[i] = v[j];
				v[j] = aux;
			}
		}
	i=0;
	(*radacina) = creare_arbore(nr_prod, v, &i);
	return nr_prod;
}

void cerinta_6(lista1 *head1, lista1 *q, int v[])
{
	lista1 *t;
	int num, i, aux, cont = -1;

	t = alocare_nod_tip1();
	stiva* stackTop;
	stiva* newNode, *temp;

	stackTop = (stiva*)malloc(sizeof(stiva));
	temp = (stiva*)malloc(sizeof(stiva));
    for (q=head1; q!=NULL; q=q->urm){
    	stackTop = NULL;
    	num = 0;
        t = head1;

    	while (strcmp(q->nume,t->nume) !=0 && t != NULL){
    		newNode = (stiva*)malloc(sizeof(stiva));
    		newNode->val = t->pret;
            newNode->next = stackTop;
            stackTop = newNode;
            t = t->urm;
    		}
    		
    	while (stackTop != NULL){
           aux = stackTop->val;
           temp = stackTop;
           stackTop = stackTop->next;
           free(temp); 

           if (aux > (q->pret)){
             num++;
             
        	}
          else
       	  goto et1;
    	}

    et1: cont++;
    v[cont] = num;
}
}

void preorder(arbore* radacina, FILE *f)
{
    if (radacina){
       fprintf(f, "%d ", radacina->cant);
       preorder(radacina->stanga, f);
       preorder(radacina->dreapta, f);
     }
}

int main(int argc, char *argv[])
{
	FILE *f;
	lista1 *head1, *q;
	lista2 *head2, *p, *head3, *z;
	int nr_produse_market, nr_prod, *c, *v, *vect2, i;

	arbore *radacina = NULL;
    radacina = (arbore*)malloc(sizeof(arbore));
    radacina->stanga = radacina ->dreapta = NULL;
    radacina ->cant = 0;

	
	vect2 = (int*)malloc(sizeof(int)*30);
    c = (int*)malloc(sizeof(int)*10);
	head1 = alocare_nod_tip1();
    q = alocare_nod_tip1();
	head2 = alocare_nod_tip2();
	p = alocare_nod_tip2();
	head3 = alocare_nod_tip2();
	z = alocare_nod_tip2();

	f = fopen(argv[4],"w");
	if (!f){
		printf("Eroare");
		exit(1);
	}

    deschide_cerinte(argv[3], c);
	nr_produse_market = creare_lista1(argv[1], &head1);
	v = (int*)malloc(sizeof(int)*nr_produse_market);
	
   	if (c[0] == 1)
   		creare_lista2(argv[2], &head2);
   
   	if (c[1] == 1)
        cerinta_2(head1, &head2, q, p, nr_produse_market);
   	 
   	if (c[2] == 1)
   	    cerinta_3(c[6], head1, head2, &head3, q, p, z);
    
    if (c[3] == 1)
        cerinta_4(head1, head2, &head3, q, p, z);
     
    if (c[4] == 1)
        nr_prod = cerinta_5(head3, p, vect2, &radacina);

    if (c[5] == 1)
        cerinta_6(head1, q, v);
    
    if (c[0] == 1 || c[1] == 1){
    	for (p=head2; p!=NULL; p=p->urm)
   	    fprintf(f, "%s %s %d\n", p->nume, p->categorie, p->cantitate);
        fprintf(f, "\n");
      }

    if (c[2] == 1 || c[3] == 1){
       for(p=head3; p!=NULL; p=p->urm)
   	   fprintf(f, "%s %s %d\n", p->nume, p->categorie, p->cantitate);
       fprintf(f, "\n");
     }

    if (c[4] == 1){
   	preorder(radacina, f);
   	fprintf(f, "\n");
     }

    if (c[5] == 1){
   	for(i=0; i<nr_produse_market; i++)
   		fprintf(f, "%d ", v[i]);
     }

     fclose(f);

     while (head1){
     	q = head1;
     	head1 = head1->urm;
     	free(q);
     }

     while (head2){
     	p = head2;
     	head2 = head2->urm;
     	free(p);
     }

     while (head3){
     	z = head3;
     	head3 = head3->urm;
     	free(z);
     }

     free(c);
     free(v);
     free(vect2);
     sterge_arbore(radacina);
     radacina==NULL;
}
   	
